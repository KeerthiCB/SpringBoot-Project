package com.practice.dao.customerdao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.practice.entity.Customer;


@Service
public interface CustomerDao {
	public List<Customer> getAllCustomers();
}
